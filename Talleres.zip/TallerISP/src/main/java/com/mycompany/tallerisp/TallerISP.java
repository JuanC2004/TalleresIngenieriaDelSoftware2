/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tallerisp;

/**
 *
 * @author juanc
 */
public class TallerISP {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
